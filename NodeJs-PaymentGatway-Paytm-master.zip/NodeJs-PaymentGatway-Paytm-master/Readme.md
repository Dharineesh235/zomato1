# Aakash Developer 
# Paytm Payment Gateway
# generate key from https://dashboard.paytm.com/


>> Accept request at 
>> CallBack to http://localhost:3000/viewBooking?status=${_results.STATUS}&ORDERID=${_results.ORDERID}&date=${_results.TXNDATE}&bank=${_results.BANKNAME}