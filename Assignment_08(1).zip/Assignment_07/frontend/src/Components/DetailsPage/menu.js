import React from 'react'

export default function menu(props) {
    console.log(props.item);
    const vegOrNon=(props.item.isVeg ? <sub className='veg'>Veg</sub>:<sub className='non-veg'>Non-Veg</sub>)
  return (
    <div>
        
        <h5 className='itemName'>{props.item.itemName}</h5>&nbsp;{vegOrNon}<br/>
        &#8377;{props.item.itemPrice}&nbsp;<span><button className='btn btn-outline-secondary btn-sm'>+</button>&nbsp;<button className='btn btn-outline-secondary btn-sm'>-</button></span>
        <hr/>
    </div>
  )
}
