import React,{useEffect, useState} from 'react'
import '../../Styles/Details.css'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import { useParams } from 'react-router-dom';
import Modal from 'react-modal';
import GoogleButton from 'react-google-button';
import GoogleLogin from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
import { getDefaultNormalizer } from '@testing-library/react';

export default function Details() {
    const {rName}=useParams();

    const[restaurant,SetRestaurant]=useState({});
    useEffect(()=>{
        fetch(`http://localhost:7001/zomato/details/${rName}`)
        .then((response)=>response.json())
    .then((data)=>{SetRestaurant(data.data);console.log(data.data)})
    },[])
    const customStyles = {
        content: {
          height:'65%',
          width:'20%',  
          top: '50%',
          left: '50%',
          right: 'auto',
          bottom: 'auto',
          marginRight: '-50%',
          transform: 'translate(-50%, -50%)',
          boxShadow:' 3px 3px 9px 2px grey'
        },
      };
      const customStyles2 = {
        content: {
          height:'70%',
          width:'35%',  
          top: '50%',
          left: '50%',
          right: 'auto',
          bottom: 'auto',
          marginRight: '-50%',
          transform: 'translate(-50%, -50%)',
          boxShadow:' 3px 3px 9px 2px grey'
        },
      };   
    const[login,setLogin]=useState(false);
    const [placeOrder,setPlaceOrder]=useState(false);
    const [menu,setMenu]=useState([]);
    const getMenu=()=>{
        fetch(`http://localhost:7001/zomato/menu/${rName}`,{method:'GET'})
        .then((response)=>response.json())
        .then((data)=>setMenu(data.data))
    };
    const payDetails={
        id: Math.random(),
        cost: '750',
        name: 'Dharan',
        email: 'dharineesh235@gmail.com',
        phone: '6382092908',
        hotel_name: 'AMA Cafe'
    }
    const payNow=()=>{
        fetch(`http://localhost:4111/paynow`,{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(payDetails)
        })
    }
    console.log(menu);

    const responseFacebook = (response) => {
        console.log(response);
      }
      const responseGoogle = (response) => {
        console.log(response);
      }  

    const cuisineList=!(restaurant.Cuisine==undefined) && (restaurant.Cuisine.length) && <ul>
        {
            restaurant.Cuisine.map((item)=><li>{item.name}</li>)
        }
    </ul>

    const mealtypeList=!(restaurant.type==undefined) && (restaurant.type.length) && <ul>{
        restaurant.type.map((item)=><li>{item.name}</li>)
        }</ul>

    const vegOrNon=(isVeg)=>(isVeg ? <sub className='veg'>Veg</sub>:<sub className='non-veg'>Non-Veg</sub>) 

    const [totalPrice,setTotalPrice]=useState(0);
    const [count,setCount]=useState(0);

    const menuList=menu.length &&  menu.map((item)=><div>
    <h5 className='itemName'>{item.itemName}</h5>&nbsp;{vegOrNon(item.isVeg)}<br/>
    <p>{item.itemDescription}</p>
    &#8377;{item.itemPrice}&nbsp;<span>
        <button 
           value={item.itemPrice} 
           onClick={(e)=>{
                 setTotalPrice((totalPrice>=0)&&(totalPrice+Number(e.target.value)));
                }}
           className='btn btn-outline-secondary btn-sm'>
              +
        </button>
        &nbsp;
        <button
            value={item.itemPrice} 
            onClick={(e)=>{
                   setTotalPrice((totalPrice>0)&&totalPrice-Number(e.target.value));
                }}  
            className='btn btn-outline-secondary btn-sm'>
                -
        </button></span>
    <hr/>
    </div>)
    
  return (
    <div>
        <div className='headbar'>
            <span className='eLogo'>e!</span>
            <div className='accountManage'>
                <button className='LogInButton'><a className='a1' onClick={()=>setLogin(true)}>Log In</a></button>
                <div className='CreateAcc'>
                    <button href='...' className='AccInButton'><a className='a1'>Create Account</a></button>
                </div>
            </div>
        </div>
        <center>
        <div className='imageTag'>
            <img src={restaurant.thumb} height='450px' width='100%'></img>
        </div></center>
        <div className='bakeryName'>
            <span><h2>{restaurant.name}</h2></span> <button className='btn btn-danger orderButton' onClick={()=>{setPlaceOrder(true);getMenu()}}>Place Online Order</button>
            <div className='Tabsall'>
            <Tabs>
                <TabList>
                <Tab>Overview</Tab>
                <Tab>Contact</Tab>
                </TabList>

                <TabPanel>
                <h2>About the place</h2>
                <h4>Cuisine</h4>
                {cuisineList}
                <h4>Meal Type</h4>
                {mealtypeList}
                <h4>Average Cost</h4>
                &#8377;{restaurant.cost}
                </TabPanel>

                <TabPanel>
                <h4>Phone</h4>
                {restaurant.contact_number}
                <h4>Address</h4>
                {restaurant.address}
                </TabPanel>
            </Tabs>
            </div>

        </div>
        <div className='modelLogin'>
        <Modal
         isOpen={login}
         style={customStyles}
         contentLabel="Example Modal"
        >
           <h2> Login
           
                <button className='x' onClick={()=>setLogin(false)}>x</button></h2>
                <div className='logInbtns'>
                    <div>
                        <input type='text' placeholder='Enter your User Name'/><br/><br/>
                        <input type='password' placeholder='Enter Your Password'/><br/><br/>
                        <button className='btn btn-primary'>LogIn</button>
                    </div>
                       
                <div className='google'>
                <GoogleLogin
                    clientId="1021090884211-u92l9v86p37r96dfq9b11q2e2asl4mol.apps.googleusercontent.com"
                    buttonText="LOGIN WITH GOOGLE"
                    onSuccess={responseGoogle}
                    onFailure={responseGoogle}
                    cookiePolicy={'single_host_origin'}
                /> <br/> <br/> 
                {/* <GoogleButton
                    onClick={() => { console.log('Google button clicked') }}
                    type="dark"
                    disabled={false}
                    label='LOGIN WITH GOOGLE'
                ></GoogleButton> <br/> */}
                <FacebookLogin
                    appId="859576005343218"
                    autoLoad={false}
                    fields="name,email,picture"
                    callback={responseFacebook} 
                ></FacebookLogin>
                </div>

                </div>    
        </Modal>
        </div>

        <Modal
          isOpen={placeOrder}
        // isOpen={false}
          style={customStyles2}
        >
            <span><button className='x' onClick={()=>setPlaceOrder(false)}>x</button></span>
            <span><h2>Place Your Order</h2></span> <br/>
            <span><h4 className='total'>Total: &nbsp;{totalPrice}</h4></span>
             <button className='paybtn btn btn-danger' onClick={()=>payNow()}>Pay Now</button><br/><br/>
            {menuList}
        </Modal>
        
    </div>
  )
}
